bootGame ={
	create:function(){
	    game.physics.startSystem(Phaser.Physics.ARCADE);
        
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forceLascape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.world.setBounds(0,0,800,1200);

        
        game.state.start("preloadGame");

},
        update: function () {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setShowAll();
        game.scale.refresh();
    }


}
preloadGame = {
	preload:function () {
    game.load.image("background","img/background.png");
    game.load.image("background1","img/background1.png");
    game.load.image("background2","img/background2.png");
    game.load.image("bamboo","img/bamboo.png");
    game.load.image("bamboo1","img/bamboo1.png");
    game.load.image("bamboo2","img/bamboo2.png");
    game.load.image("poste","img/poste.png");
    game.load.image("poste1","img/poste1.png");
    game.load.image("poste2","img/poste2.png");
    game.load.image("title","img/title.png");
    game.load.image("back","img/back.png");
    game.load.image("bback","img/bback.png");
    game.load.image('restart','img/restart.png',338,0);
    game.load.image('gameover','img/gameover.png');
    game.load.audio('kansyon','audio/music.mp3');


    game.load.spritesheet("start","img/startbut.png",250,0);
    game.load.spritesheet("about","img/aboutbut.png",250,0);
    game.load.spritesheet("howplay","img/howplay.png",250,0);
    game.load.spritesheet("menu","img/menubut.png",250,0);
    game.load.spritesheet('character','img/character.png',84,150);
    game.load.spritesheet('player2','img/player 2.png',84,150);
    game.load.spritesheet('pauseButton','img/pause.png',79,0);
    game.load.spritesheet('leftButton','img/leftbut.png',79,0);
    game.load.spritesheet('rightButton','img/rightbut.png',79,0);
    game.load.spritesheet('upButton','img/upbut.png',79,0);
    game.load.spritesheet('downButton','img/downbut.png',79,0);

},
create:function(){
game.state.start("menuGame");
}
}

menuGame = {
	create:function(){
	
	
	game.add.image(0,0,"title");
	startButton = game.add.button(300,650,'start', this.actionOnClick, this);
    howplayButton = game.add.button(300,750,'howplay', this.howplayOnClick, this);
        aboutButton = game.add.button(300,850,'about',this.aboutOnClick, this);
        menu = game.add.sprite(200,500,"menu");

        // menuText =game.add.text(200,700,"MENU",{"fill":"#fff"});
        menu.scale.x = 1.5;
        menu.scale.y = 1.5;

},
	actionOnClick: function(){
        startButton.visible =! startButton.visible;
        startButton.destroy();
        game.state.start("playGame");


    },


    howplayOnClick: function(){
            howplaypage=game.add.image(0,0,"background2");
            restartButton=game.add.button(550,1100,"back",restartB,this);
            function restartB() {
            howplaypage.visible =! restartButton.visible;
            restartButton.destroy();

           // window.location.href=window.location.href;
            game.state.start("menuGame");
            }
        },
        aboutOnClick: function(){
            aboutpage=game.add.image(0,0,"background1");
            restartButton=game.add.button(550,1100,"back",restartB,this);
            function restartB() {
            aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

           // window.location.href=window.location.href;
            game.state.start("menuGame");
            }
        },

}
playGame = {
	create:function(){

game.add.image(0,0,"background");

	player = game.add.sprite(200,900,'character');
    player2 = game.add.sprite(500,100,'player2');

    player.animations.add('walk-right',[6,7,8],7,true);
    player.animations.add('walk-left',[5,4,3],7,true);
    player.animations.add('walk-up',[9,10,11],7,true);
    player.animations.add('walk-down',[0,1,2],7,true);

    player2.animations.add('walk-right',[6,7,8],7,true);
    player2.animations.add('walk-left',[5,4,3],7,true);
    player2.animations.add('walk-up',[9,10,11],7,true);
    player2.animations.add('walk-down',[0,1,2],7,true);

    buttonleft = game.add.button(600,1050,"leftButton",this.walkLeft),this;
    buttonright = game.add.button(700,1050,"rightButton",this.walkRight),this;
    buttonup = game.add.button(100,1000,"upButton",this.walkUp),this;
    buttondown = game.add.button(100,1100,"downButton",this.walkDown),this;

    kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();

    restartButton=game.add.button(1,3,"bback",restartB,this);
            function restartB() {   
            restartButton.destroy();
            game.state.start("menuGame");
            
            }

    scoreText = game.add.text(80,50, 'Score: 0', {fontSize:'100px Arialss', fill: '#0080C0'});
    //gameOverText = game.add.text(350,600,"",{fontSize:'120px Arial',fill:'#FFFFFF'});

    bamboo = game.add.sprite(700,800,"bamboo");
   game.physics.arcade.enable(bamboo);
 	
    bamboo.body.immovable = true;
    
    bamboo1 = game.add.sprite(400,250,"bamboo1");
    game.physics.arcade.enable(bamboo1);

    bamboo1.body.immovable = true;

    bamboo2 = game.add.sprite(200,600,"bamboo2");
    game.physics.arcade.enable(bamboo2);

    bamboo2.body.immovable = true;

    poste = game.add.sprite(100,120,"poste");
    game.physics.arcade.enable(poste);

    poste.body.immovable = true;

    poste1 = game.add.sprite(600,100,"poste1");
    game.physics.arcade.enable(poste1);

    poste1.body.immovable = true;

    poste2= game.add.sprite(420,800,"poste2");
    game.physics.arcade.enable(poste2);

    poste2.body.immovable = true;

    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    //player.body.gravity.y = 1000;

    game.physics.arcade.enable(player2);
    player2.body.collideWorldBounds = true;
    //player2.body.immovable = true;


    this.pauseButton = this.game.add.sprite(700,25, 'pauseButton');
    this.pauseButton.inputEnabled = true;
    this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
    this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this); 

    titlepage = game.add.sprite(0,0, "title");
    startButton = game.add.button(300,800,'start', this.actionOnClick, this);
   
    titlepage.visible =!startButton.visible;
    startButton.destroy();

},

update:function() {
    game.scale.pageAlignVertically = true;
    game.scale.pageAlignHorizontally = true;
    game.scale.setShowAll();
    game.scale.refresh();

   
    
    game.physics.arcade.collide(player,bamboo,this.touchBamboo);
    game.physics.arcade.collide(player,bamboo1,this.touchBamboo1);
    game.physics.arcade.collide(player,bamboo2,this.touchBamboo2);
    game.physics.arcade.collide(player,poste,this.touchPoste);
    game.physics.arcade.collide(player,poste1,this.touchPoste1);
    game.physics.arcade.collide(player,poste2,this.touchPoste2);
    game.physics.arcade.collide(player,poste);

//game.physics.arcade.overlap(player,resetform,this.Resetform);

    game.physics.arcade.collide(player2,bamboo,this.touchBamboo);
    game.physics.arcade.collide(player2,bamboo1,this.touchBamboo1);
    game.physics.arcade.collide(player2,bamboo2,this.touchBamboo2);
    game.physics.arcade.collide(player2,poste,this.touchPoste);
    game.physics.arcade.collide(player2,poste1,this.touchPoste1);
    game.physics.arcade.collide(player2,poste2,this.touchPoste2);
    game.physics.arcade.collide(player2,poste);
    
    game.physics.arcade.collide(player,player2,this.touchPlayer);
    game.physics.arcade.collide(player,player2);


},
	//var a = 0;
    actionOnClick:function (){
    titlepage.visible =!startButton.visible;
    startButton.destroy();


        
},
    walkLeft:function(){
    	buttonleft.frame = 1;
        player.body.velocity.x = -500;
        player.animations.play('walk-left');
        player2.animations.play('walk-right');
              player2.body.velocity.x = +100;

    
    	setTimeout(function(){
        buttonleft.frame = 0;
        player.body.velocity.x = 0;
        //player.animations.stop();
    },100)
  },
    walkRight:function (){
        buttonright.frame = 1;
        player.body.velocity.x = 500;
        player.animations.play('walk-right');
        player2.animations.play('walk-left');
         player2.body.velocity.x = -100;

    	setTimeout(function(){
        buttonright.frame = 0;
        player.body.velocity.x = 0;
        //player.animations.stop();
    },100)
},
        walkUp:function () {
        buttonup.frame = 1;
        player.body.velocity.y = -500;
        player.animations.play('walk-up');
        player2.animations.play('walk-down');
         player2.body.velocity.y = +100;
        
        setTimeout(function(){
        buttonup.frame = 0;
        player.body.velocity.y = 0;
        //player.animations.stop();
        },100)
},
        walkDown:function () {
        buttondown.frame = 1;
        player.body.velocity.y = 500;
        player.animations.play('walk-down');
        player2.animations.play('walk-up');
         player2.body.velocity.y = -100;

        setTimeout(function(){
        buttondown.frame = 0;
        player.body.velocity.y = 0;
        //player.animations.stop();
        },100)
},
		touchBamboo:function (player,bamboo){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
        //player.body.position=900
},
		touchBamboo1:function (player,bamboo1){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
},
		touchBamboo2:function (player,bamboo2){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
},
		touchPoste:function (player,poste){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
},
		touchPoste1:function (player,poste1){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
},
		touchPoste2:function (player,poste2){

        score  += 1;
        scoreText.text = 'Score:  ' + score;
},
        touchPlayer:function (player,player2){
        player.kill();
        game._paused = true
        
        kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");

        restartButton=game.add.button(250,1000,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }


        // game.input.onTap.addOnce(this.restart,this);
 },
    	restart:function  () {
    	window.location.href=window.location.href;
    	stateText.visible = false;
},
loopAudio:function(time){
    setInterval(function(){
        kansyon.play();
    },time)
},

}

winGame = {
	
}

loseGame = {
	
}