var w = 800,h = 1200;
	
var menutext;
var playtext;
var abouttext;
var titlepage;
var startButton;
var player, player2, keyboard, gameover, bamboo,bamboo1,bamboo2, poste,poste1,poste2, button, buttonLeft, buttonRight, buttonUp, buttonDown;
var scoreText;
var score = 0;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

var howplayButton;
var howplaypage;

var aboutButton;
var aboutpage;



var gameOver;


game.state.add("bootGame",bootGame);
game.state.add("preloadGame",preloadGame);
game.state.add("menuGame",menuGame);
game.state.add("playGame",playGame);
game.state.add("winGame",winGame);
game.state.add("loseGame",loseGame);

game.state.start("bootGame");


